import re

class SimpleChatbot:
    def _init_(self):
        self.responses = {
            r'hello|hi|hey': 'Hello! How can I assist you today?',
            r'how are you|how are you doing': 'I am just a program, but I am doing great! How about you?',
            r'what is your name': 'I am a chatbot created to assist you. I don’t have a name.',
            r'bye|goodbye': 'Goodbye! Have a great day!',
            r'what is your purpose|what can you do': 'I am here to help answer your questions and chat with you.',
        }
    
    def get_response(self, user_input):
        for pattern, response in self.responses.items():
            if re.search(pattern, user_input, re.IGNORECASE):
                return response
        return "Sorry, I don't understand that."

def main():
    chatbot = SimpleChatbot()
    print("Chatbot: Hi! Type 'bye' to exit.")
    
    while True:
        user_input = input("You: ")
        if re.search(r'bye|goodbye', user_input, re.IGNORECASE):
            print("Chatbot: Goodbye! Have a great day!")
            break
        
        response = chatbot.get_response(user_input)
        print(f"Chatbot: {response}")

if __name__ == "__main__":
    main()